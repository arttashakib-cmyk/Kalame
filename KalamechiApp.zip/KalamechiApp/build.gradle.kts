plugins {
    id("com.android.application") version "9.4.1" apply false
    id("org.jetbrains.kotlin.android") version "2.4.10" apply false
    id("com.google.devtools.ksp") version "2.4.10-2.0.2" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.4.10" apply false
}
