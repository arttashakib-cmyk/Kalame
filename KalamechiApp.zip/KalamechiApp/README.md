# کلمه‌چی (Kalamechi) — Native Android English Grammar App

آموزش گرامر کاربردی انگلیسی در ۳۰ روز — اپلیکیشن کاملاً native اندروید.

## نسخه‌های فنی (اکتبر ۲۰۲۶)

| جزء | نسخه |
|-----|------|
| Android Gradle Plugin | **9.4.1** |
| Kotlin | **2.4.10** |
| Gradle | **9.6.0** |
| compileSdk / targetSdk | **36** |
| Compose BOM | **2026.09.00** |
| Navigation Compose | **2.10.2** |
| Lifecycle | **2.11.0** |
| Room | **2.8.5** |
| Activity Compose | **1.12.0** |
| Coroutines | **1.10.2** |
| KSP | **2.4.10-2.0.2** |
| minSdk | 26 |
| Java | 17 |

## ویژگی‌ها

- Kotlin + Jetpack Compose + Material 3
- Glassmorphism UI + انیمیشن‌های spring / staggered / progress
- Room برای پیشرفت، تلاش‌ها، نشان‌گذاری و آمار
- Navigation Compose با انتقال‌های fade/slide
- ۳۰ روز محتوای کامل + تمرین تعاملی
- آفلاین کامل، RTL فارسی، LTR برای مثال‌های انگلیسی
- GitHub Actions برای ساخت APK

## ساخت APK با GitHub Actions

1. ریپازیتوری بسازید و محتویات این پوشه را push کنید.
2. Actions → **Build Debug APK** → Run workflow
3. Artifact با نام `kalamechi-debug-apk` را دانلود کنید.

## ساخت محلی

Android Studio (نسخه سازگار با AGP 9.4) → Open پروژه → Sync → Run یا `./gradlew assembleDebug`

## معماری

- UI: Compose + Material 3 + Glass components
- Navigation: Navigation Compose 2.10
- Persistence: Room 2.8
- Content: JSON در assets + Gson
- RTL: CompositionLocal LayoutDirection

## لایسنس محتوا

محتوای آموزشی متعلق به «کلمه‌چی» است. این اپلیکیشن پیاده‌سازی تعاملی برای استفاده آموزشی است.
