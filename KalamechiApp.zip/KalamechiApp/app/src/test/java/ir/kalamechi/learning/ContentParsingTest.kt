package ir.kalamechi.learning

import com.google.gson.Gson
import ir.kalamechi.learning.data.model.Lesson
import org.junit.Assert.*
import org.junit.Test

class ContentParsingTest {

    private val gson = Gson()

    @Test
    fun day01_parsesCorrectly() {
        val json = """
        {
          "day": 1,
          "id": "day_01",
          "titleFa": "ترتیب کلمات در جمله",
          "titleEn": "Word Order",
          "estimatedMinutes": 20,
          "objectives": ["test"],
          "sections": [],
          "exercises": [
            {
              "id": "day01_q1",
              "day": 1,
              "number": 1,
              "type": "MULTIPLE_CHOICE",
              "questionFa": "test",
              "options": ["A", "B"],
              "correctAnswer": "B",
              "explanation": "reason"
            }
          ],
          "summary": []
        }
        """.trimIndent()

        val lesson = gson.fromJson(json, Lesson::class.java)
        assertEquals(1, lesson.day)
        assertEquals("day_01", lesson.id)
        assertEquals("Word Order", lesson.titleEn)
        assertEquals(1, lesson.exercises.size)
        assertEquals("B", lesson.exercises[0].correctAnswer)
    }

    @Test
    fun answerEvaluation_isCaseInsensitive() {
        val correct = "I drink coffee."
        val user = "i drink coffee."
        assertTrue(user.equals(correct, ignoreCase = true))
    }
}
