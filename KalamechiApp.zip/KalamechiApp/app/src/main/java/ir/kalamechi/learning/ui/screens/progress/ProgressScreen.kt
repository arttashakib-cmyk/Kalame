package ir.kalamechi.learning.ui.screens.progress

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import ir.kalamechi.learning.KalamechiApp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProgressScreen() {
    val app = LocalContext.current.applicationContext as KalamechiApp
    var completed by remember { mutableIntStateOf(0) }
    var streak by remember { mutableIntStateOf(0) }
    var longest by remember { mutableIntStateOf(0) }
    var totalAttempts by remember { mutableIntStateOf(0) }
    var totalCorrect by remember { mutableIntStateOf(0) }

    LaunchedEffect(Unit) {
        app.progressRepository.getCompletedCount().collect { completed = it }
        app.progressRepository.getUserStats().collect { stats ->
            streak = stats?.currentStreak ?: 0
            longest = stats?.longestStreak ?: 0
            totalAttempts = stats?.totalAttempts ?: 0
            totalCorrect = stats?.totalCorrectAnswers ?: 0
        }
    }

    val accuracy = if (totalAttempts > 0) (totalCorrect * 100 / totalAttempts) else 0

    Scaffold(
        topBar = { TopAppBar(title = { Text("پیشرفت و آمار") }) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            StatRow("درس‌های تکمیل‌شده", "$completed از ۳۰")
            StatRow("رشته فعلی", "$streak روز")
            StatRow("طولانی‌ترین رشته", "$longest روز")
            StatRow("تعداد تلاش‌ها", "$totalAttempts")
            StatRow("پاسخ‌های درست", "$totalCorrect")
            StatRow("دقت کلی", "%$accuracy")

            LinearProgressIndicator(
                progress = { completed / 30f },
                modifier = Modifier.fillMaxWidth().height(12.dp)
            )
        }
    }
}

@Composable
private fun StatRow(label: String, value: String) {
    Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.padding(16.dp).fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, style = MaterialTheme.typography.bodyLarge)
            Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
    }
}
