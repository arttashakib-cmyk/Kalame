package ir.kalamechi.learning.ui.screens.search

import androidx.compose.ui.Modifier.Modifier
import androidx.compose.ui.unit.dp


import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import ir.kalamechi.learning.KalamechiApp
import ir.kalamechi.learning.data.repository.SearchResult
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(onLessonClick: (Int) -> Unit) {
    val app = LocalContext.current.applicationContext as KalamechiApp
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<SearchResult>>(emptyList()) }
    var searching by remember { mutableStateOf(false) }

    LaunchedEffect(query) {
        if (query.length < 2) {
            results = emptyList()
            return@LaunchedEffect
        }
        searching = true
        delay(300) // debounce
        results = app.contentRepository.search(query)
        searching = false
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("جستجو") }) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("جستجوی درس، گرامر یا مثال...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                shape = RoundedCornerShape(16.dp)
            )
            Spacer(Modifier.height(16.dp))

            if (searching) {
                CircularProgressIndicator(modifier = Modifier.padding(16.dp))
            } else if (results.isEmpty() && query.length >= 2) {
                Text("نتیجه‌ای یافت نشد.", style = MaterialTheme.typography.bodyLarge)
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(results) { result ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onLessonClick(result.day) },
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(Modifier.padding(16.dp)) {
                                Text("روز ${result.day}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                                Text(result.title, style = MaterialTheme.typography.titleSmall)
                                Text(result.snippet, style = MaterialTheme.typography.bodySmall, maxLines = 2)
                            }
                        }
                    }
                }
            }
        }
    }
}
