package ir.kalamechi.learning.data.local.dao

import androidx.room.*
import ir.kalamechi.learning.data.local.entity.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ProgressDao {

    // Lesson Progress
    @Query("SELECT * FROM lesson_progress ORDER BY day ASC")
    fun getAllLessonProgress(): Flow<List<LessonProgressEntity>>

    @Query("SELECT * FROM lesson_progress WHERE lessonId = :lessonId")
    fun getLessonProgress(lessonId: String): Flow<LessonProgressEntity?>

    @Query("SELECT * FROM lesson_progress WHERE isCompleted = 1")
    fun getCompletedLessons(): Flow<List<LessonProgressEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertLessonProgress(progress: LessonProgressEntity)

    @Query("UPDATE lesson_progress SET isCompleted = 1, completedAt = :timestamp WHERE lessonId = :lessonId")
    suspend fun markLessonCompleted(lessonId: String, timestamp: Long)

    @Query("UPDATE lesson_progress SET lastStudiedAt = :timestamp WHERE lessonId = :lessonId")
    suspend fun updateLastStudied(lessonId: String, timestamp: Long)

    @Query("UPDATE lesson_progress SET isBookmarked = :bookmarked WHERE lessonId = :lessonId")
    suspend fun setLessonBookmarked(lessonId: String, bookmarked: Boolean)

    // Exercise Attempts
    @Insert
    suspend fun insertAttempt(attempt: ExerciseAttemptEntity): Long

    @Query("SELECT * FROM exercise_attempt WHERE exerciseId = :exerciseId ORDER BY attemptedAt DESC")
    fun getAttemptsForExercise(exerciseId: String): Flow<List<ExerciseAttemptEntity>>

    @Query("SELECT * FROM exercise_attempt WHERE day = :day")
    fun getAttemptsForDay(day: Int): Flow<List<ExerciseAttemptEntity>>

    @Query("SELECT * FROM exercise_attempt WHERE isCorrect = 0 ORDER BY attemptedAt DESC")
    fun getIncorrectAttempts(): Flow<List<ExerciseAttemptEntity>>

    @Query("SELECT COUNT(*) FROM exercise_attempt WHERE isCorrect = 1")
    fun getTotalCorrect(): Flow<Int>

    @Query("SELECT COUNT(*) FROM exercise_attempt")
    fun getTotalAttempts(): Flow<Int>

    // Bookmarks
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBookmark(bookmark: BookmarkEntity)

    @Delete
    suspend fun deleteBookmark(bookmark: BookmarkEntity)

    @Query("SELECT * FROM bookmark ORDER BY createdAt DESC")
    fun getAllBookmarks(): Flow<List<BookmarkEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM bookmark WHERE id = :id)")
    fun isBookmarked(id: String): Flow<Boolean>

    // Study Sessions
    @Insert
    suspend fun insertSession(session: StudySessionEntity): Long

    @Query("UPDATE study_session SET endedAt = :endedAt, durationSeconds = :duration WHERE id = :id")
    suspend fun endSession(id: Long, endedAt: Long, duration: Int)

    // Stats
    @Query("SELECT * FROM user_stats WHERE id = 1")
    fun getUserStats(): Flow<UserStatsEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertStats(stats: UserStatsEntity)

    // Reset
    @Query("DELETE FROM lesson_progress")
    suspend fun clearLessonProgress()

    @Query("DELETE FROM exercise_attempt")
    suspend fun clearAttempts()

    @Query("DELETE FROM bookmark")
    suspend fun clearBookmarks()

    @Query("DELETE FROM study_session")
    suspend fun clearSessions()

    @Query("DELETE FROM user_stats")
    suspend fun clearStats()

    @Transaction
    suspend fun resetAllProgress() {
        clearLessonProgress()
        clearAttempts()
        clearBookmarks()
        clearSessions()
        clearStats()
    }
}
