package ir.kalamechi.learning.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import ir.kalamechi.learning.data.local.dao.ProgressDao
import ir.kalamechi.learning.data.local.entity.*

@Database(
    entities = [
        LessonProgressEntity::class,
        ExerciseAttemptEntity::class,
        BookmarkEntity::class,
        StudySessionEntity::class,
        UserStatsEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class KalamechiDatabase : RoomDatabase() {
    abstract fun progressDao(): ProgressDao

    companion object {
        @Volatile
        private var INSTANCE: KalamechiDatabase? = null

        fun getInstance(context: Context): KalamechiDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    KalamechiDatabase::class.java,
                    "kalamechi.db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
