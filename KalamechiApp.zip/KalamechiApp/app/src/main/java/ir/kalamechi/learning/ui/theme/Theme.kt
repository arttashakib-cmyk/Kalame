package ir.kalamechi.learning.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

// Glassmorphism palette
val GlassTeal = Color(0xFF0D7377)
val GlassTealLight = Color(0xFF14919B)
val GlassCoral = Color(0xFFE85A4F)
val GlassPurple = Color(0xFF7C3AED)
val SoftCream = Color(0xFFF8F5F2)
val DeepInk = Color(0xFF1A1A2E)
val GlassWhite = Color(0xE6FFFFFF)
val GlassDark = Color(0xCC1E1E2E)
val GlassBorderLight = Color(0x66FFFFFF)
val GlassBorderDark = Color(0x33FFFFFF)

private val LightColorScheme = lightColorScheme(
    primary = GlassTeal,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFB2DFDB),
    onPrimaryContainer = Color(0xFF002020),
    secondary = GlassCoral,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFDAD6),
    onSecondaryContainer = Color(0xFF410002),
    tertiary = GlassPurple,
    background = SoftCream,
    onBackground = DeepInk,
    surface = Color.White.copy(alpha = 0.72f),
    onSurface = DeepInk,
    surfaceVariant = Color.White.copy(alpha = 0.55f),
    onSurfaceVariant = Color(0xFF6B7280),
    outline = GlassBorderLight
)

private val DarkColorScheme = darkColorScheme(
    primary = GlassTealLight,
    onPrimary = Color(0xFF003738),
    primaryContainer = Color(0xFF00504F),
    onPrimaryContainer = Color(0xFF6FF6F6),
    secondary = Color(0xFFFFB4AB),
    onSecondary = Color(0xFF690005),
    secondaryContainer = Color(0xFF93000A),
    onSecondaryContainer = Color(0xFFFFDAD6),
    tertiary = Color(0xFFC4B5FD),
    background = Color(0xFF0F0F1A),
    onBackground = Color(0xFFE6E1E5),
    surface = GlassDark,
    onSurface = Color(0xFFE6E1E5),
    surfaceVariant = Color(0xFF2A2A3C),
    onSurfaceVariant = Color(0xFFCAC4D0),
    outline = GlassBorderDark
)

val GlassGradientLight = Brush.verticalGradient(
    colors = listOf(Color(0xFFE0F7FA), Color(0xFFF3E5F5), Color(0xFFFFF3E0))
)

val GlassGradientDark = Brush.verticalGradient(
    colors = listOf(Color(0xFF1A1A2E), Color(0xFF16213E), Color(0xFF0F3460))
)

@Composable
fun KalamechiTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = Color.Transparent.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
        }
    }
    MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
