package ir.kalamechi.learning.presentation.screens.exercise

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier.Modifier
import androidx.compose.ui.unit.dp
import ir.kalamechi.learning.presentation.components.GlassButton
import ir.kalamechi.learning.presentation.components.GlassCard

@Composable
fun ExerciseScreen(day: Int, onBack: () -> Unit) {
    var showAnswer by remember { mutableStateOf(false) }
    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("تمرین روز $day", style = MaterialTheme.typography.headlineSmall)
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("جای خالی را پر کنید: She ___ to school every day.")
            if (showAnswer) {
                Text("پاسخ: goes", color = MaterialTheme.colorScheme.primary)
            }
        }
        GlassButton(
            text = if (showAnswer) "مخفی کردن پاسخ" else "نمایش پاسخ",
            onClick = { showAnswer = !showAnswer },
            modifier = Modifier.fillMaxWidth()
        )
        GlassButton(text = "بازگشت", onClick = onBack, modifier = Modifier.fillMaxWidth())
    }
}
