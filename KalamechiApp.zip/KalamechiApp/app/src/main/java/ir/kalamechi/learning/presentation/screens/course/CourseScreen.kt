package ir.kalamechi.learning.presentation.screens.course

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import ir.kalamechi.learning.presentation.components.GlassCard

@Composable
fun CourseScreen(onOpenLesson: (Int) -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Text("دوره ۳۰ روزه", style = MaterialTheme.typography.headlineSmall)
        }
        items((1..30).toList()) { day ->
            GlassCard(onClick = { onOpenLesson(day) }, modifier = Modifier.fillMaxWidth()) {
                Text("روز $day — درس گرامر")
            }
        }
    }
}
