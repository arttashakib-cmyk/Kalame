package ir.kalamechi.learning.data.repository

import ir.kalamechi.learning.data.local.dao.ProgressDao
import ir.kalamechi.learning.data.local.entity.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.time.LocalDate
import java.time.format.DateTimeFormatter

class ProgressRepository(private val dao: ProgressDao) {

    fun getAllLessonProgress(): Flow<List<LessonProgressEntity>> = dao.getAllLessonProgress()

    fun getLessonProgress(lessonId: String): Flow<LessonProgressEntity?> =
        dao.getLessonProgress(lessonId)

    fun getCompletedCount(): Flow<Int> =
        dao.getCompletedLessons().map { it.size }

    fun getUserStats(): Flow<UserStatsEntity?> = dao.getUserStats()

    fun getIncorrectAttempts(): Flow<List<ExerciseAttemptEntity>> = dao.getIncorrectAttempts()

    fun getAllBookmarks(): Flow<List<BookmarkEntity>> = dao.getAllBookmarks()

    suspend fun ensureLessonProgressExists(lessonId: String, day: Int) {
        val existing = dao.getLessonProgress(lessonId).first()
        if (existing == null) {
            dao.upsertLessonProgress(
                LessonProgressEntity(
                    lessonId = lessonId,
                    day = day,
                    lastStudiedAt = System.currentTimeMillis()
                )
            )
        } else {
            dao.updateLastStudied(lessonId, System.currentTimeMillis())
        }
    }

    suspend fun markLessonCompleted(lessonId: String, day: Int) {
        ensureLessonProgressExists(lessonId, day)
        dao.markLessonCompleted(lessonId, System.currentTimeMillis())
        updateStreak()
    }

    suspend fun recordExerciseAttempt(
        exerciseId: String,
        day: Int,
        userAnswer: String,
        isCorrect: Boolean
    ) {
        val previous = dao.getAttemptsForExercise(exerciseId).first()
        val attemptNumber = previous.size + 1
        dao.insertAttempt(
            ExerciseAttemptEntity(
                exerciseId = exerciseId,
                day = day,
                userAnswer = userAnswer,
                isCorrect = isCorrect,
                attemptedAt = System.currentTimeMillis(),
                attemptNumber = attemptNumber
            )
        )
        val stats = dao.getUserStats().first() ?: UserStatsEntity()
        dao.upsertStats(
            stats.copy(
                totalAttempts = stats.totalAttempts + 1,
                totalCorrectAnswers = stats.totalCorrectAnswers + if (isCorrect) 1 else 0
            )
        )
    }

    suspend fun toggleBookmark(
        id: String,
        lessonId: String,
        day: Int,
        type: String,
        title: String
    ) {
        val current = dao.isBookmarked(id).first()
        if (current) {
            dao.deleteBookmark(BookmarkEntity(id, lessonId, day, type, title, 0))
        } else {
            dao.insertBookmark(
                BookmarkEntity(
                    id = id,
                    lessonId = lessonId,
                    day = day,
                    type = type,
                    title = title,
                    createdAt = System.currentTimeMillis()
                )
            )
        }
    }

    private suspend fun updateStreak() {
        val today = LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE)
        val stats = dao.getUserStats().first() ?: UserStatsEntity()
        val last = stats.lastStudyDate

        val newStreak = when {
            last == null -> 1
            last == today -> stats.currentStreak
            LocalDate.parse(last).plusDays(1).toString() == today -> stats.currentStreak + 1
            else -> 1
        }

        dao.upsertStats(
            stats.copy(
                currentStreak = newStreak,
                longestStreak = maxOf(stats.longestStreak, newStreak),
                lastStudyDate = today
            )
        )
    }

    suspend fun resetAllProgress() {
        dao.resetAllProgress()
    }
}
