package ir.kalamechi.learning.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "lesson_progress")
data class LessonProgressEntity(
    @PrimaryKey val lessonId: String,
    val day: Int,
    val isCompleted: Boolean = false,
    val completedAt: Long? = null,
    val lastStudiedAt: Long? = null,
    val isBookmarked: Boolean = false
)

@Entity(tableName = "exercise_attempt")
data class ExerciseAttemptEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val exerciseId: String,
    val day: Int,
    val userAnswer: String,
    val isCorrect: Boolean,
    val attemptedAt: Long,
    val attemptNumber: Int = 1
)

@Entity(tableName = "bookmark")
data class BookmarkEntity(
    @PrimaryKey val id: String,          // sectionId or exerciseId
    val lessonId: String,
    val day: Int,
    val type: String,                    // "section" or "exercise"
    val title: String,
    val createdAt: Long
)

@Entity(tableName = "study_session")
data class StudySessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val day: Int,
    val lessonId: String,
    val startedAt: Long,
    val endedAt: Long? = null,
    val durationSeconds: Int = 0
)

@Entity(tableName = "user_stats")
data class UserStatsEntity(
    @PrimaryKey val id: Int = 1,
    val currentStreak: Int = 0,
    val longestStreak: Int = 0,
    val lastStudyDate: String? = null,   // yyyy-MM-dd
    val totalStudySeconds: Long = 0,
    val totalCorrectAnswers: Int = 0,
    val totalAttempts: Int = 0
)
