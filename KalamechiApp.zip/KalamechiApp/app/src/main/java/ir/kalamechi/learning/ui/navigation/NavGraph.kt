package ir.kalamechi.learning.ui.navigation

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import ir.kalamechi.learning.R
import ir.kalamechi.learning.ui.screens.course.CourseScreen
import ir.kalamechi.learning.ui.screens.exercise.ExerciseScreen
import ir.kalamechi.learning.ui.screens.home.HomeScreen
import ir.kalamechi.learning.ui.screens.lesson.LessonScreen
import ir.kalamechi.learning.ui.screens.progress.ProgressScreen
import ir.kalamechi.learning.ui.screens.review.ReviewScreen
import ir.kalamechi.learning.ui.screens.search.SearchScreen
import ir.kalamechi.learning.ui.screens.settings.SettingsScreen

sealed class Screen(
    val route: String,
    val titleRes: Int,
    val icon: ImageVector,
    val selectedIcon: ImageVector
) {
    data object Home : Screen("home", R.string.home, Icons.Outlined.Home, Icons.Filled.Home)
    data object Course : Screen("course", R.string.course, Icons.Outlined.MenuBook, Icons.Filled.MenuBook)
    data object Review : Screen("review", R.string.review, Icons.Outlined.Replay, Icons.Filled.Replay)
    data object Search : Screen("search", R.string.search, Icons.Outlined.Search, Icons.Filled.Search)
    data object Progress : Screen("progress", R.string.progress, Icons.Outlined.BarChart, Icons.Filled.BarChart)
    data object Settings : Screen("settings", R.string.settings, Icons.Outlined.Settings, Icons.Filled.Settings)
}

val bottomNavItems = listOf(Screen.Home, Screen.Course, Screen.Review, Screen.Progress, Screen.Settings)

@Composable
fun KalamechiNavHost() {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination
    val showBottomBar = bottomNavItems.any { it.route == currentDestination?.route }

    Scaffold(
        bottomBar = {
            AnimatedVisibility(
                visible = showBottomBar,
                enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
            ) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f),
                    tonalElevation = 0.dp
                ) {
                    bottomNavItems.forEach { screen ->
                        val selected = currentDestination?.hierarchy?.any { it.route == screen.route } == true
                        NavigationBarItem(
                            icon = {
                                val scale by animateFloatAsState(
                                    targetValue = if (selected) 1.15f else 1f,
                                    animationSpec = spring(dampingRatio = 0.5f, stiffness = 400f),
                                    label = "navIcon"
                                )
                                Icon(
                                    if (selected) screen.selectedIcon else screen.icon,
                                    contentDescription = null,
                                    modifier = Modifier.animateContentSize()
                                )
                            },
                            label = { Text(stringResource(screen.titleRes)) },
                            selected = selected,
                            onClick = {
                                navController.navigate(screen.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(innerPadding),
            enterTransition = {
                fadeIn(tween(280)) + slideInHorizontally(
                    initialOffsetX = { it / 8 },
                    animationSpec = tween(280, easing = FastOutSlowInEasing)
                )
            },
            exitTransition = {
                fadeOut(tween(200))
            },
            popEnterTransition = {
                fadeIn(tween(280))
            },
            popExitTransition = {
                fadeOut(tween(200)) + slideOutHorizontally(
                    targetOffsetX = { it / 8 },
                    animationSpec = tween(200)
                )
            }
        ) {
            composable(Screen.Home.route) {
                HomeScreen(
                    onContinue = { day -> navController.navigate("lesson/$day") },
                    onOpenCourse = { navController.navigate(Screen.Course.route) }
                )
            }
            composable(Screen.Course.route) {
                CourseScreen(onLessonClick = { day -> navController.navigate("lesson/$day") })
            }
            composable(Screen.Review.route) {
                ReviewScreen(
                    onLessonClick = { day -> navController.navigate("lesson/$day") },
                    onExerciseClick = { day, _ -> navController.navigate("exercise/$day") }
                )
            }
            composable(Screen.Search.route) {
                SearchScreen(onLessonClick = { day -> navController.navigate("lesson/$day") })
            }
            composable(Screen.Progress.route) { ProgressScreen() }
            composable(Screen.Settings.route) { SettingsScreen() }

            composable(
                route = "lesson/{day}",
                arguments = listOf(navArgument("day") { type = NavType.IntType }),
                enterTransition = {
                    slideInHorizontally(initialOffsetX = { it }, animationSpec = tween(300)) + fadeIn()
                },
                exitTransition = {
                    slideOutHorizontally(targetOffsetX = { -it / 4 }, animationSpec = tween(250)) + fadeOut()
                },
                popEnterTransition = {
                    slideInHorizontally(initialOffsetX = { -it / 4 }, animationSpec = tween(300)) + fadeIn()
                },
                popExitTransition = {
                    slideOutHorizontally(targetOffsetX = { it }, animationSpec = tween(250)) + fadeOut()
                }
            ) { backStackEntry ->
                val day = backStackEntry.arguments?.getInt("day") ?: 1
                LessonScreen(
                    day = day,
                    onBack = { navController.popBackStack() },
                    onExercise = { navController.navigate("exercise/$day") },
                    onPrev = {
                        if (day > 1) navController.navigate("lesson/${day - 1}") {
                            popUpTo("lesson/$day") { inclusive = true }
                        }
                    },
                    onNext = {
                        if (day < 30) navController.navigate("lesson/${day + 1}") {
                            popUpTo("lesson/$day") { inclusive = true }
                        }
                    }
                )
            }

            composable(
                route = "exercise/{day}",
                arguments = listOf(navArgument("day") { type = NavType.IntType }),
                enterTransition = {
                    slideInVertically(initialOffsetY = { it / 3 }, animationSpec = tween(300)) + fadeIn()
                },
                exitTransition = { fadeOut(tween(200)) }
            ) { backStackEntry ->
                val day = backStackEntry.arguments?.getInt("day") ?: 1
                ExerciseScreen(day = day, onBack = { navController.popBackStack() })
            }
        }
    }
}
