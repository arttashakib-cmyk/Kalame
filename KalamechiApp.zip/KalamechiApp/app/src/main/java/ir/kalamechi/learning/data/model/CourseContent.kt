package ir.kalamechi.learning.data.model

/**
 * Structured educational content extracted from the Kalamechi PDF.
 * All Persian text and English examples are preserved from the source.
 */

data class Course(
    val version: Int = 1,
    val title: String = "کلمه‌چی",
    val subtitle: String = "آموزش گرامر کاربردی انگلیسی در ۳۰ روز",
    val lessons: List<Lesson>
)

data class Lesson(
    val day: Int,
    val id: String,                     // e.g. "day_01"
    val titleFa: String,
    val titleEn: String,
    val estimatedMinutes: Int = 20,
    val objectives: List<String> = emptyList(),
    val sections: List<LessonSection> = emptyList(),
    val exercises: List<Exercise> = emptyList(),
    val summary: List<String> = emptyList(),
    val isReviewDay: Boolean = false
)

data class LessonSection(
    val id: String,
    val type: SectionType,
    val title: String? = null,
    val contentFa: String? = null,
    val contentEn: String? = null,
    val examples: List<Example> = emptyList(),
    val table: ContentTable? = null,
    val notes: List<String> = emptyList(),
    val commonMistakes: List<CommonMistake> = emptyList()
)

enum class SectionType {
    INTRODUCTION,
    FORMULA,
    EXPLANATION,
    EXAMPLES,
    TABLE,
    COMMON_MISTAKES,
    NOTE,
    SUMMARY
}

data class Example(
    val english: String,
    val persian: String,
    val breakdown: Map<String, String>? = null   // e.g. "I" -> "فاعل"
)

data class ContentTable(
    val headers: List<String>,
    val rows: List<List<String>>
)

data class CommonMistake(
    val wrong: String,
    val correct: String,
    val explanation: String
)

data class Exercise(
    val id: String,                     // e.g. "day01_q1"
    val day: Int,
    val number: Int,
    val type: ExerciseType,
    val questionFa: String,
    val questionEn: String? = null,
    val options: List<String>? = null,  // for multiple choice
    val correctAnswer: String,
    val explanation: String,
    val words: List<String>? = null     // for sentence building / fill-blank
)

enum class ExerciseType {
    MULTIPLE_CHOICE,
    FILL_BLANK,
    SENTENCE_BUILD,
    MATCHING,
    TRUE_FALSE,
    OPEN_TEXT
}
