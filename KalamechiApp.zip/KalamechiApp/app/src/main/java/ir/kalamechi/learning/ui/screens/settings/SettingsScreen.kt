package ir.kalamechi.learning.ui.screens.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import ir.kalamechi.learning.KalamechiApp
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen() {
    val app = LocalContext.current.applicationContext as KalamechiApp
    val scope = rememberCoroutineScope()
    var showResetDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("تنظیمات") }) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("ظاهر", style = MaterialTheme.typography.titleMedium)
            Text(
                "پوسته روشن / تیره / سیستم از طریق تنظیمات سیستم اندروید کنترل می‌شود.",
                style = MaterialTheme.typography.bodyMedium
            )

            HorizontalDivider()

            Text("داده", style = MaterialTheme.typography.titleMedium)

            OutlinedButton(
                onClick = { showResetDialog = true },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
            ) {
                Text("بازنشانی تمام پیشرفت")
            }

            Text(
                "این عمل غیرقابل بازگشت است و تمام درس‌های تکمیل‌شده، تلاش‌ها و نشان‌گذاری‌ها را پاک می‌کند.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            HorizontalDivider()

            Text("درباره", style = MaterialTheme.typography.titleMedium)
            Text("کلمه‌چی — نسخه ۱.۰.۰", style = MaterialTheme.typography.bodyMedium)
            Text(
                "محتوای آموزشی بر اساس کتاب «آموزش گرامر کاربردی انگلیسی در ۳۰ روز» استخراج شده است.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }

    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = { Text("بازنشانی پیشرفت؟") },
            text = { Text("آیا مطمئن هستید؟ تمام پیشرفت شما پاک می‌شود و قابل بازیابی نیست.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        scope.launch {
                            app.progressRepository.resetAllProgress()
                            showResetDialog = false
                        }
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("تأیید و پاک کردن")
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) {
                    Text("انصراف")
                }
            }
        )
    }
}
