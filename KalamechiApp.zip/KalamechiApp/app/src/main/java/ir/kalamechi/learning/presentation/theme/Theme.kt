package ir.kalamechi.learning.presentation.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val Teal = Color(0xFF0D9488)
private val TealLight = Color(0xFF5EEAD4)
private val Cream = Color(0xFFFFF8F0)
private val Ink = Color(0xFF1E1B4B)

private val LightColors = lightColorScheme(
    primary = Teal,
    onPrimary = Color.White,
    secondary = Color(0xFFF43F5E),
    background = Cream,
    onBackground = Ink,
    surface = Color.White.copy(alpha = 0.9f),
    onSurface = Ink
)

private val DarkColors = darkColorScheme(
    primary = TealLight,
    onPrimary = Color(0xFF003738),
    secondary = Color(0xFFFFB4AB),
    background = Color(0xFF0F0F1A),
    onBackground = Color(0xFFE6E1E5),
    surface = Color(0xFF1A1A2E),
    onSurface = Color(0xFFE6E1E5)
)

@Composable
fun KalamechiTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColors else LightColors
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = Color.Transparent.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
        }
    }
    MaterialTheme(colorScheme = colors, typography = Typography, content = content)
}
