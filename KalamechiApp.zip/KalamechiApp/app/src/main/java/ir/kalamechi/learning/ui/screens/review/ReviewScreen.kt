package ir.kalamechi.learning.ui.screens.review

import androidx.compose.ui.Modifier.Modifier
import androidx.compose.ui.unit.dp


import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import ir.kalamechi.learning.KalamechiApp
import ir.kalamechi.learning.data.local.entity.ExerciseAttemptEntity

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReviewScreen(
    onLessonClick: (Int) -> Unit,
    onExerciseClick: (Int, String) -> Unit
) {
    val app = LocalContext.current.applicationContext as KalamechiApp
    var incorrect by remember { mutableStateOf<List<ExerciseAttemptEntity>>(emptyList()) }
    var bookmarks by remember { mutableStateOf<List<ir.kalamechi.learning.data.local.entity.BookmarkEntity>>(emptyList()) }

    LaunchedEffect(Unit) {
        app.progressRepository.getIncorrectAttempts().collect { incorrect = it }
        app.progressRepository.getAllBookmarks().collect { bookmarks = it }
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("مرور و تمرین") }) }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text("نشان‌گذاری‌ها", style = MaterialTheme.typography.titleMedium)
            }
            if (bookmarks.isEmpty()) {
                item {
                    Text("هنوز چیزی نشان‌گذاری نکرده‌اید.", style = MaterialTheme.typography.bodyMedium)
                }
            } else {
                items(bookmarks) { bm ->
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { onLessonClick(bm.day) },
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            Text("روز ${bm.day}", style = MaterialTheme.typography.labelMedium)
                            Text(bm.title, style = MaterialTheme.typography.bodyLarge)
                        }
                    }
                }
            }

            item {
                Spacer(Modifier.height(8.dp))
                Text("پاسخ‌های اشتباه", style = MaterialTheme.typography.titleMedium)
            }
            if (incorrect.isEmpty()) {
                item {
                    Text("عالی! هنوز پاسخ اشتباهی ثبت نشده.", style = MaterialTheme.typography.bodyMedium)
                }
            } else {
                items(incorrect.take(30)) { attempt ->
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable {
                            onExerciseClick(attempt.day, attempt.exerciseId)
                        },
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            Text("روز ${attempt.day} — ${attempt.exerciseId}", style = MaterialTheme.typography.labelMedium)
                            Text("پاسخ شما: ${attempt.userAnswer}", style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        }
    }
}
