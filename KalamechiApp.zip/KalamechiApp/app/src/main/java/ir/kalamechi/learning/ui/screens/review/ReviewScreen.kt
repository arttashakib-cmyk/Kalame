package ir.kalamechi.learning.ui.screens.review

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier.Modifier
import androidx.compose.ui.unit.dp
import ir.kalamechi.learning.ui.components.GlassButton

@Composable
fun ReviewScreen(onOpenExercise: (Int) -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("مرور و تمرین", style = MaterialTheme.typography.headlineSmall)
        Text("درس‌های نشان‌گذاری‌شده و تمرین‌های اشتباه اینجا نمایش داده می‌شوند.")
        GlassButton(text = "تمرین روز ۱", onClick = { onOpenExercise(1) }, modifier = Modifier.fillMaxWidth())
    }
}
