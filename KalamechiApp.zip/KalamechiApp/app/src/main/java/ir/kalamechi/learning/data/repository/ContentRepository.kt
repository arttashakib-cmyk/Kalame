package ir.kalamechi.learning.data.repository

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import ir.kalamechi.learning.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader

class ContentRepository(private val context: Context) {

    private val gson = Gson()
    private var cachedCourse: Course? = null
    private var cachedIndex: CourseIndex? = null

    data class CourseIndex(
        val version: Int,
        val title: String,
        val subtitle: String,
        val totalDays: Int,
        val lessons: List<LessonIndexEntry>
    )

    data class LessonIndexEntry(
        val day: Int,
        val id: String,
        val titleFa: String,
        val titleEn: String,
        val file: String,
        val isReview: Boolean
    )

    suspend fun getCourseIndex(): CourseIndex = withContext(Dispatchers.IO) {
        cachedIndex ?: loadIndex().also { cachedIndex = it }
    }

    suspend fun getLesson(day: Int): Lesson? = withContext(Dispatchers.IO) {
        val index = getCourseIndex()
        val entry = index.lessons.find { it.day == day } ?: return@withContext null
        loadLessonFromAssets(entry.file)
    }

    suspend fun getLessonById(id: String): Lesson? = withContext(Dispatchers.IO) {
        val index = getCourseIndex()
        val entry = index.lessons.find { it.id == id } ?: return@withContext null
        loadLessonFromAssets(entry.file)
    }

    suspend fun getAllLessons(): List<Lesson> = withContext(Dispatchers.IO) {
        val index = getCourseIndex()
        index.lessons.mapNotNull { loadLessonFromAssets(it.file) }
    }

    suspend fun search(query: String): List<SearchResult> = withContext(Dispatchers.IO) {
        if (query.isBlank()) return@withContext emptyList()
        val q = query.trim().lowercase()
        val results = mutableListOf<SearchResult>()
        val index = getCourseIndex()

        index.lessons.forEach { entry ->
            if (entry.titleFa.contains(q, ignoreCase = true) ||
                entry.titleEn.lowercase().contains(q)
            ) {
                results.add(
                    SearchResult(
                        type = SearchResultType.LESSON,
                        day = entry.day,
                        lessonId = entry.id,
                        title = entry.titleFa,
                        snippet = entry.titleEn
                    )
                )
            }
            // Load lesson for deeper search only if needed; for performance we can limit
            val lesson = loadLessonFromAssets(entry.file) ?: return@forEach
            lesson.sections.forEach { section ->
                val text = listOfNotNull(
                    section.title,
                    section.contentFa,
                    section.contentEn
                ).joinToString(" ")
                if (text.lowercase().contains(q)) {
                    results.add(
                        SearchResult(
                            type = SearchResultType.SECTION,
                            day = entry.day,
                            lessonId = entry.id,
                            sectionId = section.id,
                            title = section.title ?: entry.titleFa,
                            snippet = text.take(120)
                        )
                    )
                }
                section.examples.forEach { ex ->
                    if (ex.english.lowercase().contains(q) || ex.persian.contains(q)) {
                        results.add(
                            SearchResult(
                                type = SearchResultType.EXAMPLE,
                                day = entry.day,
                                lessonId = entry.id,
                                title = ex.english,
                                snippet = ex.persian
                            )
                        )
                    }
                }
            }
        }
        results.distinctBy { it.title + it.day }.take(50)
    }

    private fun loadIndex(): CourseIndex {
        val json = readAsset("content/course_index.json")
        return gson.fromJson(json, CourseIndex::class.java)
    }

    private fun loadLessonFromAssets(fileName: String): Lesson? {
        return try {
            val json = readAsset("content/lessons/$fileName")
            gson.fromJson(json, Lesson::class.java)
        } catch (e: Exception) {
            // Return a minimal scaffold for days not yet fully extracted
            null
        }
    }

    private fun readAsset(path: String): String {
        // Content is bundled under assets/content/
        return context.assets.open(path).use { stream ->
            BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).readText()
        }
    }
}

data class SearchResult(
    val type: SearchResultType,
    val day: Int,
    val lessonId: String,
    val sectionId: String? = null,
    val title: String,
    val snippet: String
)

enum class SearchResultType {
    LESSON, SECTION, EXAMPLE, EXERCISE
}
