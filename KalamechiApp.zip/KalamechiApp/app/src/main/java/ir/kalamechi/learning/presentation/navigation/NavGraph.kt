package ir.kalamechi.learning.presentation.navigation

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.Replay
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import ir.kalamechi.learning.R
import ir.kalamechi.learning.presentation.screens.course.CourseScreen
import ir.kalamechi.learning.presentation.screens.exercise.ExerciseScreen
import ir.kalamechi.learning.presentation.screens.home.HomeScreen
import ir.kalamechi.learning.presentation.screens.lesson.LessonScreen
import ir.kalamechi.learning.presentation.screens.progress.ProgressScreen
import ir.kalamechi.learning.presentation.screens.review.ReviewScreen
import ir.kalamechi.learning.presentation.screens.search.SearchScreen
import ir.kalamechi.learning.presentation.screens.settings.SettingsScreen

sealed class Screen(
    val route: String,
    val titleRes: Int,
    val icon: ImageVector,
    val selectedIcon: ImageVector
) {
    data object Home : Screen("home", R.string.home, Icons.Outlined.Home, Icons.Filled.Home)
    data object Course : Screen("course", R.string.course, Icons.Outlined.MenuBook, Icons.Filled.MenuBook)
    data object Review : Screen("review", R.string.review, Icons.Outlined.Replay, Icons.Filled.Replay)
    data object Progress : Screen("progress", R.string.progress, Icons.Outlined.BarChart, Icons.Filled.BarChart)
    data object Settings : Screen("settings", R.string.settings, Icons.Outlined.Settings, Icons.Filled.Settings)
}

val bottomNavItems = listOf(
    Screen.Home, Screen.Course, Screen.Review, Screen.Progress, Screen.Settings
)

@Composable
fun KalamechiNavHost() {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination
    val showBottomBar = bottomNavItems.any { it.route == currentDestination?.route }

    Scaffold(
        bottomBar = {
            AnimatedVisibility(
                visible = showBottomBar,
                enter = slideInVertically { it } + fadeIn(),
                exit = slideOutVertically { it } + fadeOut()
            ) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f),
                    tonalElevation = 0.dp
                ) {
                    bottomNavItems.forEach { screen ->
                        val selected =
                            currentDestination?.hierarchy?.any { it.route == screen.route } == true
                        NavigationBarItem(
                            icon = {
                                Icon(
                                    if (selected) screen.selectedIcon else screen.icon,
                                    contentDescription = null
                                )
                            },
                            label = { Text(stringResource(screen.titleRes)) },
                            selected = selected,
                            onClick = {
                                navController.navigate(screen.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Home.route) {
                HomeScreen(
                    onOpenCourse = { navController.navigate(Screen.Course.route) },
                    onOpenLesson = { day -> navController.navigate("lesson/$day") },
                    onOpenSearch = { navController.navigate("search") }
                )
            }
            composable(Screen.Course.route) {
                CourseScreen(
                    onOpenLesson = { day -> navController.navigate("lesson/$day") }
                )
            }
            composable(Screen.Review.route) {
                ReviewScreen(
                    onOpenExercise = { day -> navController.navigate("exercise/$day") }
                )
            }
            composable(Screen.Progress.route) {
                ProgressScreen()
            }
            composable(Screen.Settings.route) {
                SettingsScreen()
            }
            composable(
                route = "lesson/{day}",
                arguments = listOf(navArgument("day") { type = NavType.IntType })
            ) { entry ->
                val day = entry.arguments?.getInt("day") ?: 1
                LessonScreen(
                    day = day,
                    onBack = { navController.popBackStack() },
                    onOpenExercise = { navController.navigate("exercise/$day") },
                    onOpenLesson = { d -> navController.navigate("lesson/$d") }
                )
            }
            composable(
                route = "exercise/{day}",
                arguments = listOf(navArgument("day") { type = NavType.IntType })
            ) { entry ->
                val day = entry.arguments?.getInt("day") ?: 1
                ExerciseScreen(
                    day = day,
                    onBack = { navController.popBackStack() }
                )
            }
            composable("search") {
                SearchScreen(
                    onOpenLesson = { day -> navController.navigate("lesson/$day") },
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }
}
