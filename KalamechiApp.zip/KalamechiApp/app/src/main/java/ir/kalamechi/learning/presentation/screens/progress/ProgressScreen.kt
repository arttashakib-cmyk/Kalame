package ir.kalamechi.learning.presentation.screens.progress

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import ir.kalamechi.learning.presentation.components.GlassCard

@Composable
fun ProgressScreen() {
    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("پیشرفت", style = MaterialTheme.typography.headlineSmall)
        GlassCard {
            Text("درس تکمیل‌شده: ۰ / ۳۰")
            Text("رشته یادگیری: ۰ روز")
        }
    }
}
