package ir.kalamechi.learning.ui.screens.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier.Modifier
import androidx.compose.ui.unit.dp
import ir.kalamechi.learning.ui.components.GlassButton
import ir.kalamechi.learning.ui.components.GlassCard

@Composable
fun HomeScreen(
    onOpenCourse: () -> Unit,
    onOpenLesson: (Int) -> Unit,
    onOpenSearch: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("کلمه‌چی", style = MaterialTheme.typography.headlineMedium)
        Text("یادگیری انگلیسی در ۳۰ روز", style = MaterialTheme.typography.bodyLarge)
        GlassButton(text = "دوره ۳۰ روزه", onClick = onOpenCourse, modifier = Modifier.fillMaxWidth())
        GlassButton(text = "جستجو", onClick = onOpenSearch, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Text("درس‌های اخیر", style = MaterialTheme.typography.titleMedium)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items((1..5).toList()) { day ->
                GlassCard(onClick = { onOpenLesson(day) }, modifier = Modifier.fillMaxWidth()) {
                    Text("روز $day")
                }
            }
        }
    }
}
