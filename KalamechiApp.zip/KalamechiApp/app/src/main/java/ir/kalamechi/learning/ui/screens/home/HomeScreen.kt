package ir.kalamechi.learning.ui.screens.home

import androidx.compose.ui.Modifier.Modifier
import androidx.compose.ui.unit.dp


import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.outlined.LocalFireDepartment
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import ir.kalamechi.learning.KalamechiApp
import ir.kalamechi.learning.ui.components.AnimatedProgressBar
import ir.kalamechi.learning.ui.components.FadeInItem
import ir.kalamechi.learning.ui.components.GlassCard
import ir.kalamechi.learning.ui.components.GlassButton
import ir.kalamechi.learning.ui.theme.GlassGradientDark
import ir.kalamechi.learning.ui.theme.GlassGradientLight
import kotlinx.coroutines.flow.combine

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onContinue: (Int) -> Unit,
    onOpenCourse: () -> Unit
) {
    val app = LocalContext.current.applicationContext as KalamechiApp
    val isDark = !MaterialTheme.colorScheme.background.let {
        (0.299 * it.red + 0.587 * it.green + 0.114 * it.blue) > 0.5
    }

    var totalDays by remember { mutableIntStateOf(30) }
    var completedCount by remember { mutableIntStateOf(0) }
    var streak by remember { mutableIntStateOf(0) }
    var nextDay by remember { mutableIntStateOf(1) }
    var lastLessonTitle by remember { mutableStateOf("هنوز شروع نکرده‌اید") }
    var appeared by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        appeared = true
        val index = app.contentRepository.getCourseIndex()
        totalDays = index.totalDays
        combine(
            app.progressRepository.getAllLessonProgress(),
            app.progressRepository.getUserStats()
        ) { progressList, stats ->
            val completed = progressList.count { it.isCompleted }
            completedCount = completed
            streak = stats?.currentStreak ?: 0
            nextDay = progressList.filter { !it.isCompleted }.minByOrNull { it.day }?.day
                ?: (completed + 1).coerceAtMost(30)
            val last = progressList.filter { it.lastStudiedAt != null }.maxByOrNull { it.lastStudiedAt!! }
            lastLessonTitle = if (last != null) {
                index.lessons.find { it.day == last.day }?.titleFa ?: "روز ${last.day}"
            } else "هنوز شروع نکرده‌اید"
        }.collect { }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(if (isDark) GlassGradientDark else GlassGradientLight)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(Modifier.height(12.dp))

            FadeInItem(appeared, 0) {
                Column {
                    Text(
                        "کلمه‌چی",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "آموزش گرامر کاربردی انگلیسی",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            FadeInItem(appeared, 80) {
                GlassCard {
                    Text("پیشرفت کلی", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(12.dp))
                    AnimatedProgressBar(
                        progress = completedCount / totalDays.toFloat(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "$completedCount از $totalDays درس تکمیل‌شده",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            FadeInItem(appeared, 160) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    GlassCard(modifier = Modifier.weight(1f)) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                Icons.Outlined.LocalFireDepartment,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(Modifier.height(6.dp))
                            AnimatedCounter(streak)
                            Text("روز پیاپی", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    GlassCard(modifier = Modifier.weight(1f)) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                Icons.Outlined.MenuBook,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(Modifier.height(6.dp))
                            AnimatedCounter(completedCount)
                            Text("درس تمام‌شده", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }

            FadeInItem(appeared, 240) {
                GlassButton(
                    text = if (completedCount == 0) "شروع یادگیری — روز ۱"
                    else "ادامه یادگیری — روز $nextDay",
                    onClick = { onContinue(nextDay) },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            FadeInItem(appeared, 320) {
                GlassCard {
                    Text(
                        "آخرین درس",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(lastLessonTitle, style = MaterialTheme.typography.bodyLarge)
                }
            }

            FadeInItem(appeared, 400) {
                GlassButton(
                    text = "مشاهده همه ۳۰ روز",
                    onClick = onOpenCourse,
                    primary = false,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun AnimatedCounter(value: Int) {
    var displayed by remember { mutableIntStateOf(0) }
    LaunchedEffect(value) {
        val step = if (value > displayed) 1 else -1
        while (displayed != value) {
            displayed += step
            kotlinx.coroutines.delay(40)
        }
    }
    Text(
        "$displayed",
        style = MaterialTheme.typography.headlineSmall,
        fontWeight = FontWeight.Bold
    )
}
