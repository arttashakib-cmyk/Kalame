package ir.kalamechi.learning.ui.screens.course

import androidx.compose.ui.Modifier.Modifier
import androidx.compose.ui.unit.dp


import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.outlined.PlayCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import ir.kalamechi.learning.KalamechiApp
import ir.kalamechi.learning.data.repository.ContentRepository
import ir.kalamechi.learning.ui.components.GlassCard
import ir.kalamechi.learning.ui.theme.GlassGradientDark
import ir.kalamechi.learning.ui.theme.GlassGradientLight

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CourseScreen(onLessonClick: (Int) -> Unit) {
    val app = LocalContext.current.applicationContext as KalamechiApp
    val isDark = !MaterialTheme.colorScheme.background.let {
        (0.299 * it.red + 0.587 * it.green + 0.114 * it.blue) > 0.5
    }
    var lessons by remember { mutableStateOf<List<ContentRepository.LessonIndexEntry>>(emptyList()) }
    var completedIds by remember { mutableStateOf<Set<String>>(emptySet()) }
    var appeared by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        appeared = true
        val index = app.contentRepository.getCourseIndex()
        lessons = index.lessons
        app.progressRepository.getAllLessonProgress().collect { list ->
            completedIds = list.filter { it.isCompleted }.map { it.lessonId }.toSet()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(if (isDark) GlassGradientDark else GlassGradientLight)
    ) {
        Column(Modifier.fillMaxSize()) {
            Text(
                "دوره ۳۰ روزه",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp)
            )

            LazyColumn(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                itemsIndexed(lessons, key = { _, it -> it.id }) { index, lesson ->
                    val isCompleted = completedIds.contains(lesson.id)
                    StaggeredItem(appeared, index) {
                        GlassCard(onClick = { onLessonClick(lesson.day) }) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                // Day circle with scale animation when completed
                                val circleScale by animateFloatAsState(
                                    targetValue = if (isCompleted) 1.05f else 1f,
                                    animationSpec = spring(dampingRatio = 0.5f),
                                    label = "circle"
                                )
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .scale(circleScale)
                                        .clip(CircleShape)
                                        .background(
                                            if (isCompleted) MaterialTheme.colorScheme.primary
                                            else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (isCompleted) {
                                        Icon(
                                            Icons.Default.Check,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.onPrimary
                                        )
                                    } else {
                                        Text(
                                            "${lesson.day}",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }

                                Spacer(Modifier.width(14.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        lesson.titleFa,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        lesson.titleEn,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    if (lesson.isReview) {
                                        Spacer(Modifier.height(4.dp))
                                        Text(
                                            "مرور",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.secondary
                                        )
                                    }
                                }

                                Icon(
                                    Icons.Outlined.PlayCircle,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                        }
                    }
                }
                item { Spacer(Modifier.height(24.dp)) }
            }
        }
    }
}

@Composable
private fun StaggeredItem(
    appeared: Boolean,
    index: Int,
    content: @Composable () -> Unit
) {
    val delay = (index * 40).coerceAtMost(400)
    val alpha by animateFloatAsState(
        targetValue = if (appeared) 1f else 0f,
        animationSpec = tween(400, delay, FastOutSlowInEasing),
        label = "staggerAlpha"
    )
    val offsetY by animateFloatAsState(
        targetValue = if (appeared) 0f else 30f,
        animationSpec = tween(400, delay, FastOutSlowInEasing),
        label = "staggerY"
    )
    Box(
        modifier = Modifier.graphicsLayer {
            this.alpha = alpha
            translationY = offsetY
        }
    ) { content() }
}
