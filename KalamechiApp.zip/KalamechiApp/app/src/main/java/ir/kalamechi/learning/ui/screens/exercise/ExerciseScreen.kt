package ir.kalamechi.learning.ui.screens.exercise
import androidx.compose.ui.Modifier.Modifier

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import ir.kalamechi.learning.KalamechiApp
import ir.kalamechi.learning.data.model.ExerciseType
import ir.kalamechi.learning.data.model.Lesson
import ir.kalamechi.learning.ui.components.AnimatedProgressBar
import ir.kalamechi.learning.ui.components.GlassCard
import ir.kalamechi.learning.ui.components.GlassButton
import ir.kalamechi.learning.ui.theme.GlassGradientDark
import ir.kalamechi.learning.ui.theme.GlassGradientLight
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExerciseScreen(day: Int, onBack: () -> Unit) {
    val app = LocalContext.current.applicationContext as KalamechiApp
    val scope = rememberCoroutineScope()
    val isDark = !MaterialTheme.colorScheme.background.let {
        (0.299 * it.red + 0.587 * it.green + 0.114 * it.blue) > 0.5
    }

    var lesson by remember { mutableStateOf<Lesson?>(null) }
    var currentIndex by remember { mutableIntStateOf(0) }
    var selectedAnswer by remember { mutableStateOf<String?>(null) }
    var showResult by remember { mutableStateOf(false) }
    var isCorrect by remember { mutableStateOf(false) }

    LaunchedEffect(day) { lesson = app.contentRepository.getLesson(day) }

    val exercises = lesson?.exercises ?: emptyList()
    val current = exercises.getOrNull(currentIndex)

    // Feedback bounce animation
    val feedbackScale by animateFloatAsState(
        targetValue = if (showResult) 1f else 0.6f,
        animationSpec = spring(dampingRatio = 0.45f, stiffness = 300f),
        label = "feedback"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(if (isDark) GlassGradientDark else GlassGradientLight)
    ) {
        Column(Modifier.fillMaxSize()) {
            // Top bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت")
                }
                Text(
                    "تمرین‌های روز $day",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
            }

            if (current == null) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        "سؤال ${currentIndex + 1} از ${exercises.size}",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary
                    )
                    AnimatedProgressBar(
                        progress = (currentIndex + 1) / exercises.size.toFloat(),
                        modifier = Modifier.fillMaxWidth()
                    )

                    GlassCard {
                        Text(
                            current.questionFa,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    // Options with animated selection
                    when (current.type) {
                        ExerciseType.MULTIPLE_CHOICE, ExerciseType.FILL_BLANK -> {
                            current.options?.forEach { option ->
                                val selected = selectedAnswer == option
                                val bgColor by animateColorAsState(
                                    targetValue = when {
                                        showResult && option == current.correctAnswer ->
                                            MaterialTheme.colorScheme.primaryContainer
                                        showResult && selected && !isCorrect ->
                                            MaterialTheme.colorScheme.errorContainer
                                        selected -> MaterialTheme.colorScheme.surfaceVariant
                                        else -> MaterialTheme.colorScheme.surface.copy(alpha = 0.7f)
                                    },
                                    animationSpec = tween(300),
                                    label = "optBg"
                                )
                                GlassCard(
                                    onClick = { if (!showResult) selectedAnswer = option },
                                    cornerRadius = 14.dp
                                ) {
                                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                                        Text(option, style = MaterialTheme.typography.bodyLarge)
                                    }
                                }
                            }
                        }
                        ExerciseType.SENTENCE_BUILD -> {
                            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    current.words?.forEach { word ->
                                        FilterChip(
                                            selected = selectedAnswer?.contains(word) == true,
                                            onClick = {
                                                if (!showResult) {
                                                    selectedAnswer = if (selectedAnswer == null) word
                                                    else "$selectedAnswer $word"
                                                }
                                            },
                                            label = { Text(word) }
                                        )
                                    }
                                }
                                selectedAnswer?.let {
                                    Spacer(Modifier.height(8.dp))
                                    Text("پاسخ شما: $it", style = MaterialTheme.typography.bodyLarge)
                                }
                            }
                        }
                        else -> {
                            OutlinedTextField(
                                value = selectedAnswer ?: "",
                                onValueChange = { if (!showResult) selectedAnswer = it },
                                modifier = Modifier.fillMaxWidth(),
                                label = { Text("پاسخ خود را بنویسید") },
                                enabled = !showResult,
                                shape = RoundedCornerShape(14.dp)
                            )
                        }
                    }

                    // Animated result card
                    AnimatedVisibility(
                        visible = showResult,
                        enter = scaleIn(spring(dampingRatio = 0.5f)) + fadeIn(),
                        exit = scaleOut() + fadeOut()
                    ) {
                        GlassCard(
                            modifier = Modifier.scale(feedbackScale)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    if (isCorrect) Icons.Default.CheckCircle else Icons.Default.Cancel,
                                    contentDescription = null,
                                    tint = if (isCorrect) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(32.dp)
                                )
                                Spacer(Modifier.width(10.dp))
                                Text(
                                    if (isCorrect) "درست! 🎉" else "اشتباه",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(Modifier.height(8.dp))
                            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                                Text(
                                    "پاسخ صحیح: ${current.correctAnswer}",
                                    style = MaterialTheme.typography.bodyLarge
                                )
                            }
                            Spacer(Modifier.height(4.dp))
                            Text(current.explanation, style = MaterialTheme.typography.bodyMedium)
                        }
                    }

                    // Actions
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        if (!showResult) {
                            GlassButton(
                                text = "بررسی پاسخ",
                                onClick = {
                                    val answer = selectedAnswer?.trim() ?: ""
                                    isCorrect = answer.equals(current.correctAnswer, ignoreCase = true) ||
                                            answer.contains(current.correctAnswer, ignoreCase = true)
                                    showResult = true
                                    scope.launch {
                                        app.progressRepository.recordExerciseAttempt(
                                            current.id, day, answer, isCorrect
                                        )
                                    }
                                },
                                modifier = Modifier.weight(1f),
                                enabled = !selectedAnswer.isNullOrBlank()
                            )
                        } else {
                            if (currentIndex < exercises.size - 1) {
                                GlassButton(
                                    text = "سؤال بعدی",
                                    onClick = {
                                        currentIndex++
                                        selectedAnswer = null
                                        showResult = false
                                    },
                                    modifier = Modifier.weight(1f)
                                )
                            } else {
                                GlassButton(
                                    text = "پایان تمرین‌ها",
                                    onClick = onBack,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            GlassButton(
                                text = "دوباره",
                                onClick = { selectedAnswer = null; showResult = false },
                                primary = false,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    Spacer(Modifier.height(32.dp))
                }
            }
        }
    }
}
