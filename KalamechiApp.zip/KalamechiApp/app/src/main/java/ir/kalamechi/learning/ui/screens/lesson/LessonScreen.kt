package ir.kalamechi.learning.ui.screens.lesson

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier.Modifier
import androidx.compose.ui.unit.dp
import ir.kalamechi.learning.ui.components.GlassButton
import ir.kalamechi.learning.ui.components.GlassCard

@Composable
fun LessonScreen(
    day: Int,
    onBack: () -> Unit,
    onOpenExercise: () -> Unit,
    onOpenLesson: (Int) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("روز $day", style = MaterialTheme.typography.headlineSmall)
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text(
                "محتوای درس روز $day از دوره کلمه‌چی.\nتوضیحات فارسی و مثال‌های انگلیسی در نسخه کامل از فایل JSON بارگذاری می‌شوند.",
                style = MaterialTheme.typography.bodyLarge
            )
        }
        GlassButton(text = "تمرین‌ها", onClick = onOpenExercise, modifier = Modifier.fillMaxWidth())
        if (day < 30) {
            GlassButton(text = "درس بعدی", onClick = { onOpenLesson(day + 1) }, modifier = Modifier.fillMaxWidth())
        }
        GlassButton(text = "بازگشت", onClick = onBack, modifier = Modifier.fillMaxWidth())
    }
}
