package ir.kalamechi.learning.ui.screens.lesson

import androidx.compose.ui.Modifier.Modifier
import androidx.compose.ui.unit.dp


import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.Quiz
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import ir.kalamechi.learning.KalamechiApp
import ir.kalamechi.learning.data.model.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LessonScreen(
    day: Int,
    onBack: () -> Unit,
    onExercise: () -> Unit,
    onPrev: () -> Unit,
    onNext: () -> Unit
) {
    val app = LocalContext.current.applicationContext as KalamechiApp
    val scope = rememberCoroutineScope()
    var lesson by remember { mutableStateOf<Lesson?>(null) }
    var isCompleted by remember { mutableStateOf(false) }
    var isBookmarked by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(true) }

    LaunchedEffect(day) {
        loading = true
        lesson = app.contentRepository.getLesson(day)
        app.progressRepository.ensureLessonProgressExists("day_${day.toString().padStart(2, '0')}", day)
        app.progressRepository.getLessonProgress("day_${day.toString().padStart(2, '0')}").collect {
            isCompleted = it?.isCompleted == true
            isBookmarked = it?.isBookmarked == true
        }
        loading = false
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("روز $day", style = MaterialTheme.typography.titleMedium)
                        lesson?.let {
                            Text(it.titleFa, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت")
                    }
                },
                actions = {
                    IconButton(onClick = {
                        scope.launch {
                            val id = "day_${day.toString().padStart(2, '0')}"
                            app.progressRepository.toggleBookmark(
                                id = id,
                                lessonId = id,
                                day = day,
                                type = "lesson",
                                title = lesson?.titleFa ?: "روز $day"
                            )
                            isBookmarked = !isBookmarked
                        }
                    }) {
                        Icon(
                            if (isBookmarked) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                            contentDescription = "نشان‌گذاری"
                        )
                    }
                }
            )
        },
        bottomBar = {
            Surface(tonalElevation = 3.dp) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onPrev, enabled = day > 1) {
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null)
                        Spacer(Modifier.width(4.dp))
                        Text("قبلی")
                    }
                    if (lesson?.exercises?.isNotEmpty() == true) {
                        FilledTonalButton(onClick = onExercise) {
                            Icon(Icons.Outlined.Quiz, contentDescription = null)
                            Spacer(Modifier.width(4.dp))
                            Text("تمرین‌ها")
                        }
                    }
                    TextButton(onClick = onNext, enabled = day < 30) {
                        Text("بعدی")
                        Spacer(Modifier.width(4.dp))
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                    }
                }
            }
        }
    ) { padding ->
        if (loading) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else if (lesson == null) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("محتوای این روز هنوز استخراج کامل نشده است.")
                    Spacer(Modifier.height(8.dp))
                    Text("عنوان از فهرست دوره موجود است.", style = MaterialTheme.typography.bodySmall)
                }
            }
        } else {
            val l = lesson!!
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Header
                Text(l.titleEn, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                Text(l.titleFa, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)

                if (l.objectives.isNotEmpty()) {
                    Card(shape = RoundedCornerShape(12.dp)) {
                        Column(Modifier.padding(16.dp)) {
                            Text("امروز چه یاد می‌گیری؟", style = MaterialTheme.typography.titleSmall)
                            Spacer(Modifier.height(8.dp))
                            l.objectives.forEach { obj ->
                                Text("• $obj", style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }

                // Sections
                l.sections.forEach { section ->
                    SectionCard(section)
                }

                // Summary
                if (l.summary.isNotEmpty()) {
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            Text("خلاصه یک‌دقیقه‌ای", style = MaterialTheme.typography.titleSmall)
                            Spacer(Modifier.height(8.dp))
                            l.summary.forEach { s ->
                                Text("• $s", style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }

                // Mark complete
                Button(
                    onClick = {
                        scope.launch {
                            app.progressRepository.markLessonCompleted(
                                "day_${day.toString().padStart(2, '0')}",
                                day
                            )
                            isCompleted = true
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !isCompleted
                ) {
                    if (isCompleted) {
                        Icon(Icons.Default.Check, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("تکمیل شده")
                    } else {
                        Text("علامت‌گذاری به عنوان تکمیل‌شده")
                    }
                }

                Spacer(Modifier.height(32.dp))
            }
        }
    }
}

@Composable
private fun SectionCard(section: LessonSection) {
    Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            section.title?.let {
                Text(it, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            }
            section.contentFa?.let {
                Text(it, style = MaterialTheme.typography.bodyLarge)
            }
            section.contentEn?.let {
                // English formula — force LTR
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            it,
                            style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.padding(12.dp),
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            section.examples.forEach { example ->
                ExampleBlock(example)
            }

            section.table?.let { table ->
                ContentTableView(table)
            }

            section.notes.forEach { note ->
                Surface(
                    color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.4f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        "نکته: $note",
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }

            section.commonMistakes.forEach { mistake ->
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("اشتباه رایج", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.error)
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        Text("❌ ${mistake.wrong}", style = MaterialTheme.typography.bodyMedium)
                        Text("✅ ${mistake.correct}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
                    }
                    Text(mistake.explanation, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
private fun ExampleBlock(example: Example) {
    SelectionContainer {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(12.dp)) {
                    Text(
                        example.english,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Medium
                    )
                    // Persian under LTR block still readable
                    Text(
                        example.persian,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun ContentTableView(table: ContentTable) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        // Simple card-based table for mobile
        table.rows.forEach { row ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                shape = RoundedCornerShape(8.dp)
            ) {
                Column(Modifier.padding(10.dp)) {
                    row.forEachIndexed { index, cell ->
                        val header = table.headers.getOrNull(index) ?: ""
                        if (header.isNotEmpty()) {
                            Text("$header: $cell", style = MaterialTheme.typography.bodyMedium)
                        } else {
                            Text(cell, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        }
    }
}
