package ir.kalamechi.learning

import android.app.Application
import ir.kalamechi.learning.data.local.KalamechiDatabase
import ir.kalamechi.learning.data.repository.ContentRepository
import ir.kalamechi.learning.data.repository.ProgressRepository

class KalamechiApp : Application() {

    lateinit var database: KalamechiDatabase
        private set

    lateinit var contentRepository: ContentRepository
        private set

    lateinit var progressRepository: ProgressRepository
        private set

    override fun onCreate() {
        super.onCreate()
        database = KalamechiDatabase.getInstance(this)
        contentRepository = ContentRepository(this)
        progressRepository = ProgressRepository(database.progressDao())
    }
}
