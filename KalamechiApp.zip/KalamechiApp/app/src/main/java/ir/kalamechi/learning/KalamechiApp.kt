package ir.kalamechi.learning

import android.app.Application

class KalamechiApp : Application()
