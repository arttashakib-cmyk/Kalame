# Keep Gson models
-keep class ir.kalamechi.learning.data.model.** { *; }
-keepclassmembers class ir.kalamechi.learning.data.model.** { *; }
